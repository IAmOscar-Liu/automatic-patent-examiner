self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8838f81a6ce85fe864e1d9703e87fa58",
    "url": "./index.html"
  },
  {
    "revision": "34846f3ede66da3ebf59",
    "url": "./static/css/main.f309dc6e.chunk.css"
  },
  {
    "revision": "aa221304e2b072ce351a",
    "url": "./static/js/2.b09a5863.chunk.js"
  },
  {
    "revision": "854484a040bfb8da064e5506851af312",
    "url": "./static/js/2.b09a5863.chunk.js.LICENSE.txt"
  },
  {
    "revision": "34846f3ede66da3ebf59",
    "url": "./static/js/main.fb0bc5de.chunk.js"
  },
  {
    "revision": "82cf05f533f019cb235d3e51e184edd8",
    "url": "./static/js/main.fb0bc5de.chunk.js.LICENSE.txt"
  },
  {
    "revision": "0632f7b65763fc8ae583",
    "url": "./static/js/runtime-main.89f09065.js"
  },
  {
    "revision": "0ecf80d1f259b883eb63bdda2f98843a",
    "url": "./static/media/aboriginal.0ecf80d1.png"
  },
  {
    "revision": "da188ccb78f1017e9645542bb5e52d6b",
    "url": "./static/media/checked.da188ccb.png"
  },
  {
    "revision": "162602bc0df8c8d4a3da0c9ddf062736",
    "url": "./static/media/error.162602bc.png"
  },
  {
    "revision": "7e92c6ec095f76aa32a20fe0b692091e",
    "url": "./static/media/hammer.7e92c6ec.png"
  },
  {
    "revision": "d5b7655bb6ab6f1a24b6ac537fcb639a",
    "url": "./static/media/img_386644.d5b7655b.png"
  },
  {
    "revision": "10f1e7d21e337bd77279f54892a53332",
    "url": "./static/media/search.10f1e7d2.png"
  },
  {
    "revision": "c873ba962a497dd427035410d8e30ce6",
    "url": "./static/media/setting.c873ba96.png"
  },
  {
    "revision": "cbc061dea8466915a1668ce07841798c",
    "url": "./static/media/switch.cbc061de.png"
  },
  {
    "revision": "36678d0144e6a71f67fc54a50698708f",
    "url": "./static/media/warn.36678d01.png"
  }
]);