self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e618015b671c175b4f568b2f9c3659a5",
    "url": "./index.html"
  },
  {
    "revision": "b04a42913d7a5cde3152",
    "url": "./static/css/main.151d6ccf.chunk.css"
  },
  {
    "revision": "aac39c5e60014a0db00c",
    "url": "./static/js/2.9e52522d.chunk.js"
  },
  {
    "revision": "854484a040bfb8da064e5506851af312",
    "url": "./static/js/2.9e52522d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "b04a42913d7a5cde3152",
    "url": "./static/js/main.2ba0223e.chunk.js"
  },
  {
    "revision": "82cf05f533f019cb235d3e51e184edd8",
    "url": "./static/js/main.2ba0223e.chunk.js.LICENSE.txt"
  },
  {
    "revision": "0632f7b65763fc8ae583",
    "url": "./static/js/runtime-main.89f09065.js"
  },
  {
    "revision": "0ecf80d1f259b883eb63bdda2f98843a",
    "url": "./static/media/aboriginal.0ecf80d1.png"
  },
  {
    "revision": "da188ccb78f1017e9645542bb5e52d6b",
    "url": "./static/media/checked.da188ccb.png"
  },
  {
    "revision": "162602bc0df8c8d4a3da0c9ddf062736",
    "url": "./static/media/error.162602bc.png"
  },
  {
    "revision": "7e92c6ec095f76aa32a20fe0b692091e",
    "url": "./static/media/hammer.7e92c6ec.png"
  },
  {
    "revision": "d5b7655bb6ab6f1a24b6ac537fcb639a",
    "url": "./static/media/img_386644.d5b7655b.png"
  },
  {
    "revision": "10f1e7d21e337bd77279f54892a53332",
    "url": "./static/media/search.10f1e7d2.png"
  },
  {
    "revision": "c873ba962a497dd427035410d8e30ce6",
    "url": "./static/media/setting.c873ba96.png"
  },
  {
    "revision": "cbc061dea8466915a1668ce07841798c",
    "url": "./static/media/switch.cbc061de.png"
  },
  {
    "revision": "36678d0144e6a71f67fc54a50698708f",
    "url": "./static/media/warn.36678d01.png"
  }
]);